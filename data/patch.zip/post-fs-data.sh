#!/system/bin/sh
MODDIR=${0%/*}
MODDIRV="$MODDIR/vendor/lib/modules"

# The bundled module files are named after the kernel release string they were
# built for (md_patcher-<uname -r>.ko). Pick the one matching the running
# kernel so a single flashable works on every supported kernel.
module="$MODDIRV/md_patcher-$(uname -r).ko"

if [ -f "$module" ]; then
  insmod=$MODDIR/bin/insmod2
  chmod +x $insmod
  $insmod "$module" || $insmod -f "$module" || insmod "$module"
else
  chmod +x $MODDIR/bin/resetprop
  $MODDIR/bin/resetprop ro.boot.hwlevel P0
fi
